# Conio.h for windows and linux

This library implements (parts) the of old Turbo C conio.h
See header file for suported functions.

To avoid name conflicts a prefix "c_" was added into the original functions.



## How to try the original samples? 

Turbo C online
https://www.naclbox.com/gallery/turboc


## Original documentation:

http://docs.embarcadero.com/products/rad_studio/radstudio2007/RS2007_helpupdates/HUpdate4/EN/html/devwin32/coniohpart_xml.html


